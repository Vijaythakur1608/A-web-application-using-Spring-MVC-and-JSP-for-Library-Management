package com.advancejava.service;

import com.advancejava.model.Author;

public interface GetAuthorService {

	public Author[] getAuthor();
}
