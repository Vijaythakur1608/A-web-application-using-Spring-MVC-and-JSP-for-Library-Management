package com.springboot.dto;


public class AuthorDto {
private String authorName;
	
	public void setAuthorName(String authorName) {
		this.authorName=authorName;
	}
	public String getAuthorName() {
		return authorName;
	}
}
